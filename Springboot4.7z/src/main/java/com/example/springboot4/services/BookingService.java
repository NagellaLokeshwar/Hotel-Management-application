package com.example.springboot4.services;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.springboot4.controller.BookingController;
import com.example.springboot4.dto.BookingDto;
import com.example.springboot4.exceptions.ResourceNotFoundException;
import com.example.springboot4.models.Booking;
import com.example.springboot4.models.Hotel;
import com.example.springboot4.repo.BookingRepository;
import com.example.springboot4.repo.HotelRepo;
import com.example.springboot4.repo.UserRepository;

@Service
public class BookingService {

	
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private HotelRepo hotelRepo;
	
	@Autowired
	private UserRepository userRepository;

	
	public Booking createBooking(BookingDto dto) {
		Booking b = new Booking();
		b.setUserId(dto.getUserId());
		b.setId(UUID.randomUUID().toString());
		b.setHotel(hotelRepo.findById(dto.getHotelId()).orElseThrow(() -> new ResourceNotFoundException("Hotel with id not found")));
		b.setCheckOutDate(LocalDate.parse(dto.getCheckOutDate()));
		b.setBookingDate(LocalDate.parse(dto.getBookingDate()));
		b.setPaymentStatus(dto.isPaymentDone());
		b.setUserId(dto.getUserId());
		return bookingRepository.save(b); 
	}
	
	public List<Booking> getAllByHotelId(String hotelId) {
	    if (hotelId == null || hotelId.trim().isEmpty()) {
	        throw new IllegalArgumentException("Hotel ID cannot be null or empty");
	    }

	    Hotel hotel = hotelRepo.findById(hotelId)
	            .orElseThrow(() -> new ResourceNotFoundException("Hotel with ID " + hotelId + " not found"));

	    return bookingRepository.findAllByHotel(hotel);
	}

	
	public List<Booking> getAllByUserId(String userId) {
		return bookingRepository.findAllByUserId(userId);
	}
}	
