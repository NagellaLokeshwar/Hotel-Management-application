package com.example.springboot4.services;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot4.models.User;
import com.example.springboot4.repo.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	public User createUser(User u) {
		u.setId(UUID.randomUUID().toString());
		return userRepository.save(u);
	}
}
