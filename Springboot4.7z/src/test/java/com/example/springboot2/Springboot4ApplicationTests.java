package com.example.springboot2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
